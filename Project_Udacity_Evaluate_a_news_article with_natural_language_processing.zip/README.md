Article Analysis Tool

This project is a web tool that allows users to analyze news articles using Natural Language Processing (NLP) by providing a URL. It uses an external API for NLP processing.

The purpose of this project is to practice and implement:

Configuring Webpack

Using Sass for styling

Utilizing Webpack loaders and plugins

Designing layouts and pages

Implementing service workers

Sending requests to external APIs


Getting Started

First, install the required dependencies:

npm install

If you encounter any issues, use:

npm install --legacy-peer-deps

To start the server in the development environment:

npm run start

This will start the server on port 8000.

To build and serve the client side:

npm run build-dev

The project can then be accessed at:

http://localhost:3000/

API Setup

To use the application, you need an API key. Replace the placeholder in the .env file with the following:

API_KEY = 647ceb3cc82a045b79852e62c461f579

Deployment

You can deploy this project to any hosting platform.


---