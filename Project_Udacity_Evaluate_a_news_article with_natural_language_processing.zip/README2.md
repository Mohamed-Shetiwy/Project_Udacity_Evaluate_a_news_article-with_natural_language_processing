Project Overview

This project was successfully submitted and passed the evaluation as part of the Udacity Nanodegree Program Scholarship.

Open Source Contribution

The project is open-source, allowing anyone to benefit from, modify, or build upon it. It is specifically designed to showcase the skills acquired during the Nanodegree program.

Feel free to use this project as a reference or starting point for your own work. Contributions are welcome to enhance its functionality and features.

Author

This project was developed by Mohamed Tarek El-Sayed Gharib Shetiwy.

Facebook: https://www.facebook.com/mohamed.tarek.shetiwy

GitHub: https://github.com/Mohamed-Shetiwy

Linkedin: https://www.linkedin.com/in/m0hamedt2rek?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app

Acknowledgment

This project is a result of the invaluable opportunity provided by the Udacity Nanodegree Program Scholarship, which enabled me to deepen my skills as a Front-End Web Developer.